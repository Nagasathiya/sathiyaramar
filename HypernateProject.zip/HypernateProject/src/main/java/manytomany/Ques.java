package manytomany;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;


@Entity
@Table (name="Ques")
public class Ques {

	 @Id
	    @Column(name="USER_ID")
	    @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private int Id;
	    
	    @Column(name="Q_NAME") 
	    private String Q_Name;
	    
	    @ManyToMany(targetEntity=Answers.class,cascade= {CascadeType.ALL})
		@JoinTable(name="Matching_Check",
	    joinColumns= {@JoinColumn(name="q_id")},
	    inverseJoinColumns={@JoinColumn(name="ans_id")})
	    
		private List<Answers>answer;

		public int getId() {
			return Id;
		}

		public void setId(int id) {
			Id = id;
		}
		
		public String getQ_Name() {
			return Q_Name;
		}

		public void setQ_Name(String q_Name) {
			Q_Name = q_Name;
		}

		public List<Answers> getAnswer() {
			return answer;
		}

		public void setAnswer(List<Answers> answer) {
			this.answer = answer;
		}

		
	    
}

