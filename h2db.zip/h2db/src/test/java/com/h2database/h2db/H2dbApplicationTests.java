package com.h2database.h2db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2dbApplicationTests {

	@Test
	void contextLoads() {
	}

}
