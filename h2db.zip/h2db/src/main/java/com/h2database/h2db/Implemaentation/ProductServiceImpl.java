package com.h2database.h2db.Implemaentation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.h2database.h2db.Entity.Product;
import com.h2database.h2db.Repository.ProductRepo;
import com.h2database.h2db.Services.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo productRepo;

    @Override
    public Product getProductById(int id) {
        return productRepo.findById(id).get();
    }

    @Override
    public Product insertProduct(Product product) {
        return productRepo.save(product);
    }
}
