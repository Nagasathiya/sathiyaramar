package onlineTest;

public interface JButtonGroup {

}
