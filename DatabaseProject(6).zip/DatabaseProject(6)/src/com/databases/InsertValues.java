package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class InsertValues extends connectdb{
	public void insertvalues() throws ClassNotFoundException, SQLException {
		
		
		    Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://Localhost:3306/market","root","sathiya");
			PreparedStatement st = conn.prepareStatement("insert into Veg(Veg_name,Veg_price,Veg_kilo)values(?,?,?),(?,?,?),(?,?,?),(?,?,?)");
			
			st.setString(1, "tomoto");
			st.setInt(2,500);
			st.setInt(3,10);
			
			
			st.setString(4, "potato");
			st.setInt(5,3000);
			st.setInt(6,10);
			
			
			st.setString(7, "brinjal");
			st.setInt(8,1000);
			st.setInt(9,15);
			 
			st.setString(10, "Carrot");
			st.setInt(11,100);
			st.setInt(12,12);
			
			
			
			
			
			
			st.executeUpdate();
		    System.out.println("--------Inserted values successfully----------");
		
	
	}
  public static void main(String[] args) throws ClassNotFoundException,SQLException
  {
	   
		
		InsertValues m3=new InsertValues();
		m3.insertvalues();
		
}
}