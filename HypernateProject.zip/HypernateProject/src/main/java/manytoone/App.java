package manytoone;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {

	 public static void main( String[] args )
	    {
	    	Configuration cfg=new Configuration();
	    	cfg.configure("manytoone.cfg.xml");
	        SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			
			HarryCharacters h1=new HarryCharacters();    
			    h1.setName("Granger");    
			    h1.setEmail("Granger@gmail.com");    		     
			   
		    HarryCharacters h2=new HarryCharacters();    
			    h2.setName("Ron");  
			    h2.setEmail("ron@gmail.com");  

			HarryCharacters h3=new HarryCharacters();    
				    h3.setName(" Fleur");    
				    h3.setEmail("fluer@gmail.com");    		     
				   
			 HarryCharacters h4=new HarryCharacters();    
				    h4.setName(" Fred");  
				    h4.setEmail("fred@gmail.com");  
				               
			 CharacterAddress address1=new  CharacterAddress();    
			    address1.setAddressLine1("4-Privet Drive");    
			    address1.setCity("Little Whinging");    
			    address1.setState("Surrey");    
			    address1.setCountry("England");    
			    address1.setPincode(201301);    
			         
			    h1.setAddress(address1);    
			    h2.setAddress(address1);
			    h3.setAddress(address1);    
			    h4.setAddress(address1);  
			  
			    session.persist(h1);    
			    session.persist(h2);  
			    session.persist(h3);    
			    session.persist(h4);  

			Transaction tx = session.beginTransaction();
			
			tx.commit(); 
			session.close();
			factory.close();
		    }

}
