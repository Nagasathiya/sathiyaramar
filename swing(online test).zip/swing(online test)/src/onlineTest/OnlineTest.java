package onlineTest;

import java.awt.*;  
import java.awt.event.*;  
import javax.swing.*;  
 
class OnlineTest extends JFrame implements ActionListener  
{  
    JLabel l;  
    JRadioButton jb[]=new JRadioButton[5];  
    JButton b1,b2;  
    ButtonGroup bg;  
    int count=0,current=0,x=1,y=1,now=0;  
    int m[]=new int[15];      
    OnlineTest(String s)  
    {  
        super(s);  
        l=new JLabel();  
        add(l);  
        bg=new ButtonGroup();  
        for(int i=0;i<5;i++)  
        {  
            jb[i]=new JRadioButton();    
            add(jb[i]);  
            bg.add(jb[i]);  
        } 
//        b3=new JButton("Back");
        b1=new JButton("Next");  
        b2=new JButton("Bookmark");
       
//        b3.addActionListener(this);       
        b1.addActionListener(this);  
        b2.addActionListener(this); 
//        add(b3);
        add(b1);
        add(b2);  
        set();  
        l.setBounds(30,40,1000,20);  
        jb[0].setBounds(60,80,1000,20);  
        jb[1].setBounds(60,110,1500,20);  
        jb[2].setBounds(60,140,2000,20);  
        jb[3].setBounds(60,170,2500,20);
//        b3.setBounds(70,240,100,30);
        b1.setBounds(190,240,100,30);  
        b2.setBounds(370,240,100,30);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        setLayout(null);  
        setLocation(250,100);  
        setVisible(true);  
        setSize(600,350);  
    }  
    public void actionPerformed(ActionEvent e)  
    {  
        if(e.getSource()==b1)  
        {  
            if(check())  
                count=count+1;  
            current++;  
            set();    
            if(current==14)  
            {  
                b1.setEnabled(false);  
                b2.setText("Result");  
            }  
        }  
        //next
        
//        if(e.getSource()==b3)  
//        {  
//            if(check())  
//                count=count-1;  
//            current--;  
//            set();    
//            if(current==13)  
//            {  
//                b1.setEnabled(false);  
//                b2.setText("Next");  
//            }  
//        }  
        
        if(e.getActionCommand().equals("Bookmark"))  
        {  
            JButton bk=new JButton("Bookmark"+x);  
            bk.setBounds(480,20+30*x,100,30);  
            add(bk);  
            bk.addActionListener(this);  
            m[x]=current;  
            x++;  
            current++;  
            set();    
            if(current==14)  
                b2.setText("Result");  
            setVisible(false);  
            setVisible(true);  
        }  
        for(int i=0,y=1;i<x;i++,y++)  
        {  
        if(e.getActionCommand().equals("Bookmark"+y))  
        {  
            if(check())  
                count=count+1;  
            now=current;  
            current=m[y];  
            set();  
            ((JButton)e.getSource()).setEnabled(false);  
            current=now;  
            
        }  
        }  
     
        if(e.getActionCommand().equals("Result"))  
        {  
            if(check())  
                count=count+1;  
            current++;  
            //System.out.println("correct ans="+count);  
            JOptionPane.showMessageDialog(this,"correct answer="+count);  
            System.exit(0);  
        }  
    }  
    void set()  
    {  
        jb[4].setSelected(true);  
        if(current==0)  
        {  
            l.setText("1:   What is the purpose of the else if statement in Java?");  
            jb[0].setText("It allows multiple conditions to be checked in sequence");
            jb[1].setText("It terminates the program if the if condition is false");
            jb[2].setText("It is not a valid statement in Java");
            jb[3].setText("It is used to declare a variable");  
        }  
        if(current==1)  
        {  
            l.setText("2:Which of the following is true about the ternary operator in Java?");
            jb[0].setText("It can replace all conditional statements");
            jb[1].setText("It requires a boolean condition");
            jb[2].setText("It can only return numeric values");
            jb[3].setText("It is slower than if-else statements");  
        }  
        if(current==2)  
        {  
            l.setText("3: Which of the following is not a decision making statement?");  
            jb[0].setText("if");
            jb[1].setText("if-else");
            jb[2].setText("switch");
            jb[3].setText("do-while");  
        }  
        if(current==3)  
        {  
            l.setText("4: Which of the following is not a valid jump statement?");  
            jb[0].setText("Break");
            jb[1].setText("goto");
            jb[2].setText("continue");
            jb[3].setText("return");  
        }  
        if(current==4)  
        {  
            l.setText("5: Which of these are selection statements in java?");  
            jb[0].setText("break");
            jb[1].setText("continue");
            jb[2].setText("for()");
            jb[3].setText("if()");  
        }  
        if(current==5)  
        {  
            l.setText("6: what happens during each iteration of a for loop?");  
            jb[0].setText("intialization statement is executed");
            jb[1].setText("condition statement is executed");
            jb[2].setText("update statement is executed");
            jb[3].setText("All of the above");  
        }  
        if(current==6)  
        {  
            l.setText("7: Which of the following Java loops will always execute at least once? ");  
            jb[0].setText(" for loop");
            jb[1].setText("while loop");
            jb[2].setText("do-while loop");  
            jb[3].setText("None of the above  ");  
        }  
        if(current==7)  
        {  
            l.setText("8: what happens if the update expression in a for loop missing?");  
            jb[0].setText("execute normally");
            jb[1].setText("throw a complication error");
            jb[2].setText("run indefinitely");  
            jb[3].setText("exit immediately");        
        }  
        if(current==8)  
        {  
            l.setText("9: what statement is used to increment the loop control variable in for loop?");  
            jb[0].setText("update");
            jb[1].setText("increment");
            jb[2].setText("modify");
            jb[3].setText("none of the above");  
        }  
        if(current==9)  
        {  
            l.setText("10: Can you nest for loops in java?");  
            jb[0].setText("Yes,but only one level deep");
            jb[1].setText("No,it is not allowed");
            jb[2].setText("Yes,nest multiple levels deep");  
            jb[3].setText("Only have the same initialization values");  
        } 
        if(current==10)  
        {  
            l.setText("11: what is a correct way to define an infinite loop?");  
            jb[0].setText("for(; ;){}");
            jb[1].setText("while(true)");
            jb[2].setText("Both A & B");  
            jb[3].setText("none of the above");  
        } 
        if(current==11)  
        {  
            l.setText("12: What keyword is used to exit a loop in java?");  
            jb[0].setText("stop");
            jb[1].setText("break");
            jb[2].setText("exit");  
            jb[3].setText("continue");  
        }
        if(current==12)  
        {  
            l.setText("13: for(i=0;i<5;i++){ S.O.P(i) }How many times executed these program?");  
            jb[0].setText("4 times");
            jb[1].setText("5 times");
            jb[2].setText("6 times");  
            jb[3].setText("infinite times");  
        } 
        if(current==13)  
        {  
            l.setText("14: What does the switch statement in java?");  
            jb[0].setText("An expression only");
            jb[1].setText("A variable & its value");
            jb[2].setText("A series of boolean expression");  
            jb[3].setText("An arithmetic operation");  
        }  
        if(current==14)  
        {  
            l.setText("15: Which loop is iterating over the elements of an array ?");  
            jb[0].setText("for loop");
            jb[1].setText("while loop");
            jb[2].setText("do-while loop");  
            jb[3].setText("All of the above");  
        }  
        l.setBounds(30,40,1000,20);  
        for(int i=0,j=0;i<=90;i+=30,j++)  
            jb[j].setBounds(50,80+i,500,20);  
    }  
    boolean check()  
    {  
        if(current==0)  
            return(jb[0].isSelected());  
        if(current==1)  
            return(jb[1].isSelected());  
        if(current==2)  
            return(jb[3].isSelected());  
        if(current==3)  
            return(jb[1].isSelected());  
        if(current==4)  
            return(jb[3].isSelected());  
        if(current==5)  
            return(jb[3].isSelected());  
        if(current==6)  
            return(jb[2].isSelected());  
        if(current==7)  
            return(jb[1].isSelected());  
        if(current==8)  
            return(jb[0].isSelected());  
        if(current==9)  
            return(jb[2].isSelected());
        if(current==10)  
            return(jb[2].isSelected());  
        if(current==11)  
            return(jb[1].isSelected());
        if(current==12)  
            return(jb[1].isSelected());  
        if(current==13)  
        	return(jb[0].isSelected()); 
        if(current==14)  
            return(jb[3].isSelected());  
        return false;  
        
    }  
    public static void main(String s[])  
    {  
        new OnlineTest("Online Test Of Java");  
    }  
}  
