package com.databases;

import java.sql.SQLException;
import java.util.Scanner;

public class connectdb {

	public static void main(String[] args)  throws ClassNotFoundException,SQLException{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter what do you want to perform????");
	System.out.println("1.CreateDB");
	System.out.println("2.CreateTable");
	System.out.println("3.insert");
	System.out.println("4.read");
	System.out.println("5.update");
	System.out.println("6.delete");
	System.out.println("Entered your Options????");
	
    int options = s.nextInt();

	switch(options) {
    case 1:
         System.out.println("---------Create Database----------");
         Createdatabase m1=new  Createdatabase ();
    	 m1.createdb();
         break;
    
    
    case 2:
    	 System.out.println("---------Create Table----------");
    	 CreateTable m2=new CreateTable ();
    	 m2.createtable();
    	 
    	 break;
    
    case 3:
    	 System.out.println("---------Insert Values into a Table----------");
    	 InsertValues m3=new InsertValues();
 		 m3.insertvalues();
    	 break;
    	
    case 4:
    	 System.out.println("---------ReadTable from the Databases----------");
    	 ReadTable m4=new ReadTable();
	     m4.read();
    	 break;
    	
    case 5:
    	 System.out.println("---------Update the Values in the Databases----------");
    	 UpdateDB m5=new UpdateDB ();
	     m5.update();
         break;
    
    case 6:
    	 System.out.println("---------Delete the values/DB/Table----------");
    	Deletedb m6=new Deletedb();
 		m6.delete();
         break;
    	
    default:
    	System.out.println("Try it is another way");
    }
	
}


}
