package onetoone;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="vehicledetails1")
public class VehicleDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int vechicleid;
	@Column(name="vehiclename")
	private String vehiclename;
	@Column(name="vehiclecolor")
	private String vehiclecolor;
	public int getVechicleid() {
		return vechicleid;
	}
	public void setVechicleid(int vechicleid) {
		this.vechicleid = vechicleid;
	}
	public String getVehiclename() {
		return vehiclename;
	}
	public void setVehiclename(String vehiclename) {
		this.vehiclename = vehiclename;
	}
	public String getVehiclecolor() {
		return vehiclecolor;
	}
	public void setVehiclecolor(String vehiclecolor) {
		this.vehiclecolor = vehiclecolor;
	}




	}

	


