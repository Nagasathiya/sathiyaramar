package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateDB extends connectdb {
	
	public void update() 
		 throws ClassNotFoundException, SQLException {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn=DriverManager.getConnection("jdbc:mysql://Localhost:3306/market","root","sathiya");
				PreparedStatement st = conn.prepareStatement("Update Veg Set veg_name='drumstick' where veg_kilo=15 ");
				
				
				st.executeUpdate();
				System.out.println("updated  successfully");
		
		
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException
	        {
		     UpdateDB m5=new UpdateDB ();
		     m5.update();
			 }
			
	}
	

