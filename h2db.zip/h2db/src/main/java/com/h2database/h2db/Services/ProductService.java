package com.h2database.h2db.Services;

import com.h2database.h2db.Entity.Product;

public interface ProductService {

	   public Product getProductById(int id );

	   public Product insertProduct (Product product);
	}
