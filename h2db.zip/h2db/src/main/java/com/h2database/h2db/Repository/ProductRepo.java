package com.h2database.h2db.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.h2database.h2db.Entity.Product;

public interface ProductRepo extends JpaRepository<Product , Integer> {
}
