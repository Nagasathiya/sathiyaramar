package onetoone;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table (name="userdetails1")
public class Userdetails {
      
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int userId;

	@Column(name="username")
	private String userName;

	@OneToOne
	@JoinColumn(name="vechicleid")
	private VehicleDetails vd;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public VehicleDetails getVd() {
		return vd;
	}

	public void setVd(VehicleDetails vd) {
		this.vd = vd;
	}

	//getters and setters

	}


