package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReadTable extends connectdb {
	
public void read() throws ClassNotFoundException, SQLException 
{
	 Class.forName("com.mysql.cj.jdbc.Driver");
	 Connection conn=DriverManager.getConnection("jdbc:mysql://Localhost:3306/ecommerce","root","sathiya");
	 Statement db = conn.createStatement();
     ResultSet res = db.executeQuery("select*from shopping");
     while(res.next()) {
    	 System.out.println(res.getString(2)+" "+res.getInt(1));
     }
     {
    	 System.out.println("--------Read Successfully----------");
     }
	
	
}
	 public static void main(String[] args) throws ClassNotFoundException,SQLException
	  {
		
	     
	     ReadTable m4=new ReadTable();
	     m4.read();
	     }
}