package onetomany;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="HarryPotter")
public class HarryPotter {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)	
  private int id;
 @Column(name="female_character")
 private String female_names;
 @Column(name="male_character")
 private String male_names;
 @Column(name="Dialogue")
 private String dialogue;
 @Column(name="Theme")
 private String themes;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFemale_names() {
	return female_names;
}
public void setFemale_names(String female_names) {
	this.female_names = female_names;
}
public String getMale_names() {
	return male_names;
}
public void setMale_names(String male_names) {
	this.male_names = male_names;
}
public String getDialogue() {
	return dialogue;
}
public void setDialogue(String dialogue) {
	this.dialogue = dialogue;
}
public String getThemes() {
	return themes;
}
public void setThemes(String themes) {
	this.themes = themes;
}
}
