package onetomany;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="HarryCharacters")
public class HarryCharacters {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)	
private int id;
@Column(name="characterName")
private String Character_names;
	@OneToMany(cascade=CascadeType.ALL)                   //Serious Conditions
    @JoinColumn(name="hid")
	private List<HarryPotter>harrypotter;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCharacter_names() {
		return Character_names;
	}
	public void setCharacter_names(String character_names) {
		Character_names = character_names;
	}
	public List<HarryPotter> getHarrypotter() {
		return harrypotter;
	}
	public void setHarrypotter(List<HarryPotter> harrypotter) {
		this.harrypotter = harrypotter;
	}
	
}

