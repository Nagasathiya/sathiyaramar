package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beanclass.RegisterBean;
import com.databases.RegisterDB;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	doGet(request, response);
		//get request parameter from register.jsp
	    PrintWriter out = response.getWriter();
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		// create obj for bean use of set enter the value(getter and setter)
		RegisterBean registerbean =new RegisterBean();
		registerbean.setFirstname(firstname);
		registerbean.setLastname(lastname);
		registerbean.setUsername(username);
		registerbean.setPassword(password);
		
		//this class contain main logic to perform function calling and database operation

		RegisterDB registerdao=new RegisterDB();
		 String registerValidate=registerdao.authorizeRegister(registerbean); 
	   
	    
	    if(registerValidate.equals("SUCCESS REGISTER"))
	    {   
//	    	request.setAttribute("WrongLoginMsg",registerValidate);
	        out.println("successfully registered");
	    	request.setAttribute("RegisterSuccessMsg",registerValidate); 
	    	request.getRequestDispatcher("Login.jsp").forward(request, response);
	    }
	    else
	    {   
	    	out.println("Register failed");
	    	request.setAttribute("RegisterErrorsMsg",registerValidate); 
	    	request.getRequestDispatcher("Registration.jsp").forward(request, response);
	    }
	}

}
