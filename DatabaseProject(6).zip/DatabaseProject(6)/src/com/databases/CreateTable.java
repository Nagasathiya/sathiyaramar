package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CreateTable extends connectdb{
	public void createtable() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://Localhost:3306/market","root","sathiya");
		Statement db = conn.createStatement();
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter you want to wish the Table Name:");
		String database = s.next();
		db.executeUpdate("create table Veg(Veg_name varchar(20),Veg_price int,Veg_kilo int)");
		System.out.println("------created table successfully------");
	}
  public static void main(String[] args) throws ClassNotFoundException,SQLException
  {
	
	CreateTable m2=new CreateTable ();
	m2.createtable();
	
}
}