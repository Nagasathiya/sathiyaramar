/**
 * 
 */
/**
 * 
 */
module QuizApplication {
	requires java.desktop;
}