package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Createdatabase extends connectdb  {
 
public  void createdb() throws SQLException, ClassNotFoundException 
   {
	   
	    Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection conn=DriverManager.getConnection("jdbc:mysql://Localhost:3306","root","sathiya");
		
	    Statement db = conn.createStatement();
	   
	    Scanner s=new Scanner(System.in);
		System.out.println("Enter you want to wish the Database Name:");
		String database = s.next();
		db.executeUpdate("create database "+database);
		System.out.println("------created database successfully------");
		
   }
  public static void main(String[] args) throws ClassNotFoundException,SQLException
  {
	  
	Createdatabase m1=new  Createdatabase ();
    m1.createdb();
	
}
}
