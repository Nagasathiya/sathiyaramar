package onetoone;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
        Configuration config = new Configuration();
        config.configure("onetoone.cfg.xml");
        SessionFactory sessionFactory = config.buildSessionFactory();
        
        Session session = sessionFactory.openSession();
        Transaction txn = session.beginTransaction();

        Userdetails ud1 = new Userdetails();
        VehicleDetails vd1 = new VehicleDetails();

        ud1.setUserName("Tamil");

        vd1.setVehiclename("Royal Enfield");
        vd1.setVehiclecolor("Black");
        
        Userdetails ud2 = new Userdetails();
        VehicleDetails vd2 = new VehicleDetails();
        ud2.setUserName("sathiya");
        
        vd2.setVehiclename("R15");
        vd2.setVehiclecolor("BLUE");
        // Persist VehicleDetails first
        session.persist(vd1);
        
        // Now set the VehicleDetails object in UserDetails
        ud1.setVd(vd1);
        
        // Persist UserDetails
        session.persist(ud1);

        txn.commit();
        
        session.close();
        sessionFactory.close();
    }
}


