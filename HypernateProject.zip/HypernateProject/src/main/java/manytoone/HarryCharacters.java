package manytoone;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity  
@Table(name="charactername1")  
public class HarryCharacters {
	@jakarta.persistence.Id  
    @GeneratedValue(strategy=GenerationType.IDENTITY)  
    @Column(name="Id")
	private int Id;  
    
    @Column(name="Name")
	private String name;    
	
    @Column(name="Email")
	private String email; 
    
	@ManyToOne(cascade=CascadeType.ALL) 
	@JoinColumn(name="Address")
	private CharacterAddress address; 
	
	public int getId() {  
	    return Id;  
	    
	    
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CharacterAddress getAddress() {
		return address;
	}

	public void setAddress(CharacterAddress address) {
		this.address = address;
	}

	public void setId(int id) {
		Id = id;
	}

	
}
