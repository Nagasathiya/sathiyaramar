package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.beanclass.LoginBean;

public class LoginDB {


	public String autorizeLogin(LoginBean loginbean) {
		
		 String username = loginbean.getUsername();
		 String password = loginbean.getPassword();
		 
		 
		   
	        String dbusername="";  //create two variable for use next process

	        String dbpassword="";

	        
		 try {
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/registerform","root","sathiya");
			  PreparedStatement pstmt=null; //create statement

	            

	            pstmt=con.prepareStatement("select * from userdetails where username=? and password=?"); //sql select query 

	            pstmt.setString(1,username);

	            pstmt.setString(2,password);

	            ResultSet rs=pstmt.executeQuery(); //execute query and set in Resultset object rs.

	             

	            while(rs.next())

	            {    

	                dbusername=rs.getString("username");   //fetchable database record username and password store in this two variable dbusername,dbpassword above created 

	                dbpassword=rs.getString("password"); 

	                

	                if(username.equals(dbusername) && password.equals(dbpassword))  //apply if condition check for fetchable database username and password are match for user input side type in textbox

	                {

	                    return "SUCCESS LOGIN"; //if valid condition return string "SUCCESS LOGIN" 

	                }

	            } 

	           

	            pstmt.close(); //close statement

	            

	            con.close(); //close connection

	           

	        }

	        catch(Exception e)

	        {

	            e.printStackTrace();

	        }

	        

	        return "WRONG USERNAME AND PASSWORD"; //if invalid condition return string "WRONG USERNAME AND PASSWORD"

	    }
	}
