package onetomany;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("onetomany.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		
		HarryPotter h1=new HarryPotter();
		h1.setFemale_names("Fleur");
		h1.setMale_names("Albus Dumbledore");
		h1.setDialogue("All she wants to do is snog me");
		h1.setThemes("True Friendship");
		
		
		HarryPotter h2=new HarryPotter();
		h2.setFemale_names("Luna Lovegood");
		h2.setMale_names("Draco Malfoy");
		h2.setDialogue("lol shut up harry");
		h2.setThemes("Never give up");
		
		
		HarryPotter h3=new HarryPotter();
		h3.setFemale_names("Ginny Weasley");
		h3.setMale_names("Ron Weasley");
		h3.setDialogue("harry potter being sassy");
		h3.setThemes("True love lasts");
		
		
		HarryPotter h4=new HarryPotter();
		h4.setFemale_names("Bellatrix");
		h4.setMale_names("Severus Snape");
		h4.setDialogue("Until the very end");
		h4.setThemes("Money isn't everything");
		
		
		ArrayList<HarryPotter>list1=new ArrayList<HarryPotter>();
		list1.add(h2);
		list1.add(h3);
		list1.add(h4);
		list1.add(h1);
		
		ArrayList<HarryPotter>list2=new ArrayList<HarryPotter>();
		list2.add(h2);
		list2.add(h3);
		list2.add(h4);
		list2.add(h1);
		
		ArrayList<HarryPotter>list3=new ArrayList<HarryPotter>();
		list3.add(h2);
		list3.add(h3);
		list3.add(h4);
		list3.add(h1);
		
		ArrayList<HarryPotter>list4=new ArrayList<HarryPotter>();
		list4.add(h2);
		list4.add(h3);
		list4.add(h4);
		list4.add(h1);
		
		HarryCharacters hc1=new HarryCharacters();

		hc1.setCharacter_names("JILL");
		hc1.setHarrypotter(list1);
		
		HarryCharacters hc2=new HarryCharacters();
		hc2.setCharacter_names("JUNG");
		hc2.setHarrypotter(list2);
		
		HarryCharacters hc3=new HarryCharacters();
		hc3.setCharacter_names("JACK");
		hc3.setHarrypotter(list3);
		
		HarryCharacters hc4=new HarryCharacters();
		hc4.setCharacter_names("PAJAK");
		hc4.setHarrypotter(list4);
		
		session.persist(hc1);
		session.persist(hc2);
		Transaction ts=session.beginTransaction();
		ts.commit();
		session.close();
		factory.close();
	}
}
