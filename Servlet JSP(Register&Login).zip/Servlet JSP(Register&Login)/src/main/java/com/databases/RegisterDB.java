package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.beanclass.RegisterBean;

public class RegisterDB {


	public String authorizeRegister(RegisterBean registerbean) {
		String firstname=registerbean.getFirstname();

        String lastname=registerbean.getLastname();

        String username=registerbean.getUsername();  //get all value through registerBean object and store in temporary variable

        String password=registerbean.getPassword();
				
     
        try

	        {

	            Class.forName("com.mysql.cj.jdbc.Driver"); //load driver

	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/registerform","root","sathiya"); //create connection
	            PreparedStatement pstmt =con.prepareStatement("insert into userdetails(firstname,lastname,username,password) values(?,?,?,?)"); //sql insert query

		            pstmt.setString(1,firstname);

		            pstmt.setString(2,lastname);

		            pstmt.setString(3,username);

		            pstmt.setString(4,password); 

		            pstmt.executeUpdate();
		           //execute query
	               
		           
		            return "SUCCESS REGISTER";
	          }
		  catch(Exception e)

	        {

	            e.printStackTrace();

	        }
	        return "FAIL REGISTER"; 
	            //if invalid return string "FAIL REGISTER"

	    }
	}

	

	


