package manytomany;

import java.util.ArrayList; 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg=new Configuration();
    	cfg.configure("manytomany.cfg.xml");
    	SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
	
		Answers a1=new Answers();
		  a1.setAnswername("Programming Language");  
		  a1.setPostedBy("James Gosling");  		
		
		Answers a2=new Answers();
		  a2.setAnswername("OOPs concept used");  
		  a2.setPostedBy("Herbert Schildt");  		
		
		Ques q1=new Ques();
		q1.setQ_Name("What is Java?");
	    ArrayList<Answers> a11=new ArrayList<Answers>();  
	    a11.add(a1);
	    a11.add(a2);
	    q1.setAnswer(a11);
	    
	    
	    Answers a3=new Answers();
		  a3.setAnswername("Multi-Threading");  
		  a3.setPostedBy("pearson");  		
		
		Answers a4=new Answers();
		  a4.setAnswername("Robust(Garbage Collection)");  
		  a4.setPostedBy("Kathy Sierra");  		
		
		Ques q2=new Ques();
		q2.setQ_Name("What are the features of Java?");
	    ArrayList<Answers> a12=new ArrayList<Answers>();  
	    a12.add(a3);
	    a12.add(a4);
	    q2.setAnswer(a12);
		 
		session.persist(q1);
		session.persist(q2);
		
		Transaction tx = session.beginTransaction();
		
		tx.commit(); 
		session.close();
		factory.close();
	    }
}
