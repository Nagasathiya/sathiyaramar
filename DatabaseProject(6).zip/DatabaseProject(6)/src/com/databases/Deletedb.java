package com.databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Deletedb{

        public void delete() throws ClassNotFoundException, SQLException 
        {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://Localhost:3306/market","root","sathiya");
		Statement st = conn.createStatement();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter value to be deletion");
		String del=s.next();
		int count=st.executeUpdate("delete from veg where veg_name="+del);
		if(count==1)
		{
			System.out.println(count+"row deleted");
		}
		else {
		System.out.println("inserted successfully");
		}
	
        }
	public static void main(String[] args)throws ClassNotFoundException, SQLException 
	
	{
		Deletedb m6=new Deletedb();
		m6.delete();
	}
}
